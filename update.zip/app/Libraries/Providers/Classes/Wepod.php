<?php

namespace App\Libraries\Providers\Classes;

use GuzzleHttp\Client;

class Wepod extends \App\Libraries\Providers\Abstractor
{


    private $guzzleConfig   = [];
    private $apiBaseUrl     = "https://api.wepod.ir/";

    public function getOptions()
    {
        return [
            'key' => [
                "label"       => "key",
            ],
            'secret' => [
                "label"       => "secret",
            ],
        ];
    }

    public function getName()
    {
        return 'wepod';
    }

    public function getLabel()
    {
        return 'ویپاد';
    }

    public function initialize()
    {
        $configs = $this->getConfigs();
        $headers = [
            'Content-Type'      => 'application/json',
            'Referer'           => 'https://web.wepod.ir/',
            'Request-ID'        => $this->generateReqId(),
            'User-Agent'        => 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
            'X-Client-Version'  => 'Wepod_web-3.18.28.8.Pas',
        ];

        $headers['Referer'] = $configs["api_key"];
        if (!empty($configs["api_key"])) {
            $headers['Authorization'] = $configs["api_key"];
        }

        $this->guzzleConfig = array_merge([
            'base_uri'  => $this->apiBaseUrl,
            'headers'   => $headers,
        ], []);

        return  $this;
    }


    public function sendMobileToken($mobile)
    {
        $params = [
            "deviceId"      => $this->generateReqId(),
            "deviceName"    => "Chrome 131",
            "mobileNumber"  => $mobile,
            "latitude"      => "0",
            "longitude"     => "0",
            "osType"        => "web_windows",
            "deviceType"    => "Desktop",
            "appVersion"    => "Wepod_web-3.18.28.8.Pas",
            "appName"       => "wepod-web",
            "clientIssuer"  => 210,
            "flowType"      => 1
        ];

        $endpoint   = "oauth2/api/v1/otp/authorize";

        $httpClient = new Client($this->guzzleConfig);
        $response   = $httpClient->post($endpoint, ['json' => $params]);

        if (!$this->responseHasError($response)) {
            $payload = json_decode((string) $response->getBody(), true);

            return $payload;
        }
    }

    public function verifyMobileToken($mobile, $code, $keyId)
    {

        $params = [
            "deviceKeyId"   => $keyId,
            "mobileNumber"  => $mobile,
            "otpCode"       => $code,
            "clientIssuer"  => 210,
            "flowType"      => 1
        ];


        $endpoint   = "oauth2/api/v1/otp/verify";
        $httpClient = new Client($this->guzzleConfig);
        $response   = $httpClient->post($endpoint, ['json' => $params]);

        if (!$this->responseHasError($response)) {
            $payload = json_decode((string) $response->getBody(), true);

            if (!empty($payload["token"]["accessToken"])) {
                return  [
                    "token" => $payload["token"]["accessToken"],
                ];
            }

            if (!empty($payload["actionUrl"]["url"])) {
                return  [
                    "auth_url" => $payload["actionUrl"]["url"],
                ];
            }
            
        }
    }

    public function getCredit()
    {
        $endpoint   = "api/Wallet/getCreditWithSign";
        $httpClient = new Client($this->guzzleConfig);
        $response   = $httpClient->post($endpoint);

        if (!$this->responseHasError($response)) {
            $payload = json_decode((string) $response->getBody(), true);
            return $payload["amount"];
        }
    }

    public function getTransDetails($invoiceId)
    {
        $params     = ["entityId" => $invoiceId];

        $endpoint   = "api/Billing/getCreditInvoiceList";

        $httpClient = new Client($this->guzzleConfig);
        $response   = $httpClient->post($endpoint, ['json' => $params]);

        if (!$this->responseHasError($response)) {
            $payload = json_decode((string) $response->getBody(), true);
        }
    }

    public function refreshToken($accToken)
    {

        $params     = ["accessToken"  => $accToken];

        $endpoint   = "oauth2/api/v1/token/refresh";
        $httpClient = new Client($this->guzzleConfig);
        $response   = $httpClient->post($endpoint, ['json' => $params]);

        if (!$this->responseHasError($response)) {
            $payload = json_decode((string) $response->getBody(), true);
            return  [
                "token" => $payload["token"]["accessToken"],
            ];
        }
    }

    public function checkPayTransaction($amount, $cardNum, $excludeRefIds = [])
    {
        $endpoint   = "api/Billing/getAccountBillWithSign";

        $startTime  = strtotime('-1 day');
        $endTime    = strtotime('now');
        $startDate  = date('Y/m/d\TH:i:s', $startTime);
        $endDate    = date('Y/m/d\TH:i:s', $endTime);

        $params = [
            "dateFrom"      => $startDate,
            "dateTo"        => $endDate,
            "filterType"    => 5,
            "size"          => 100,
            "AmountFrom"    => $amount * 10,
            "AmountTo"      => $amount * 10
        ];
        $httpClient = new Client($this->guzzleConfig);
        $response   = $httpClient->post($endpoint, ['json' => $params]);


        if (!$this->responseHasError($response)) {
            $result     = json_decode((string) $response->getBody(), true);

            $returnVals = false;
            if (!empty($result)) {

                foreach ($result as $item) {
                    $description    = $item["description"];
                    $entityId       = $item["entityId"];
                    if (!in_array($entityId, $excludeRefIds)) {
                        preg_match('/\b\d{12}(\d{4})\b/', $description, $matches);
                        if (!empty($matches[1]) && $matches[1] == $cardNum) {
                            $returnVals = [
                                "desc"      => $description,
                                "ref_id"    => $entityId,
                            ];
                            break;
                        }
                    }
                }
            }
            if (!$returnVals) {
                throw new \Exception("تراکنش مورد نظر یافت نشد");
            }

            return $returnVals;
        }
    }


    private function generateReqId()
    {
        return preg_replace_callback('/[xy]/', function ($match) {
            $random = random_int(0, 15);
            return dechex($match[0] === 'x' ? $random : ($random & 0x3 | 0x8));
        }, 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx');
    }

    private function responseHasError($response)
    {
        $responseDecoded = json_decode((string) $response->getBody());
        if (strlen((string) $response->getBody()) > 0) {
            if (!empty($responseDecoded->error)) {
                $this->throwError($response);
                return true;
            }
        } elseif ($response->getStatusCode() <= 200 && $response->getStatusCode() >= 300) {
            $this->throwError($response);
            return true;
        }

        return false;
    }

    private function throwError($response)
    {
        $body = (string) $response->getBody();
        if (strlen($body) > 0) {
            $error = \GuzzleHttp\json_decode($body);
            throw new \Exception(\App\Libraries\Providers\APIResponse::create([
                'error' => $error->error,
            ]), $error->error->message);
        }
        throw new \App\Libraries\Providers\APIException(\App\Libraries\Providers\APIResponse::create([
            'response' => $response,
        ]), 'The response is not parseable');
    }
}
